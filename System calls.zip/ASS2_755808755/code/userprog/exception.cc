// exception.cc 
//	Entry point into the Nachos kernel from user programs.
//	There are two kinds of things that can cause control to
//	transfer back to here from user code:
//
//	syscall -- The user code explicitly requests to call a procedure
//	in the Nachos kernel.  Right now, the only function we support is
//	"Halt".
//
//	exceptions -- The user code does something that the CPU can't handle.
//	For instance, accessing memory that doesn't exist, arithmetic errors,
//	etc.  
//
//	Interrupts (which can also cause control to transfer from user
//	code into the Nachos kernel) are handled elsewhere.
//
// For now, this only handles the Halt() system call.
// Everything else core dumps.
//
// Copyright (c) 1992-1996 The Regents of the University of California.
// All rights reserved.  See copyright.h for copyright notice and limitation 
// of liability and disclaimer of warranty provisions.

#include "copyright.h"
#include "main.h"
#include "syscall.h"
#include "ksyscall.h"
//----------------------------------------------------------------------
// ExceptionHandler
// 	Entry point into the Nachos kernel.  Called when a user program
//	is executing, and either does a syscall, or generates an addressing
//	or arithmetic exception.
//
// 	For system calls, the following is the calling convention:
//
// 	system call code -- r2
//		arg1 -- r4
//		arg2 -- r5
//		arg3 -- r6
//		arg4 -- r7
//
//	The result of the system call, if any, must be put back into r2. 
//
// If you are handling a system call, don't forget to increment the pc
// before returning. (Or else you'll loop making the same system call forever!)
//
//	"which" is the kind of exception.  The list of possible exceptions 
//	is in machine.h.
//----------------------------------------------------------------------

using namespace std;

void
ForkFn(int num)
{
    cout<<"Fork - Starting a new Thread"<<endl;
}

void
ExecFn(char* reg4)
{
	cout<<"Thread executing exec system call"<<endl;
	AddrSpace *space = new AddrSpace;
    ASSERT(space != (AddrSpace *)NULL);
    if (space->Load((char*)reg4)) {  
        space->Execute();         
    }
}

void
ExceptionHandler(ExceptionType which)
{
    int type = kernel->machine->ReadRegister(2);
	
    DEBUG(dbgSys, "Received Exception " << which << " type: " << type << "\n");
	
    switch (which) {
		case SyscallException:
		switch(type) {
			case SC_Halt:
			DEBUG(dbgSys, "Shutdown, initiated by user program.\n");
			
			SysHalt();
			
			ASSERTNOTREACHED();
			break;
			
			case SC_Add:
			DEBUG(dbgSys, "Add " << kernel->machine->ReadRegister(4) << " + " << kernel->machine->ReadRegister(5) << "\n");
			
			/* Process SysAdd Systemcall*/
			int result;
			result = SysAdd(/* int op1 */(int)kernel->machine->ReadRegister(4),
			/* int op2 */(int)kernel->machine->ReadRegister(5));
			
			DEBUG(dbgSys, "Add returning with " << result << "\n");
			/* Prepare Result */
			kernel->machine->WriteRegister(2, (int)result);
			
			/* Modify return point */
			{
				/* set previous programm counter (debugging only)*/
				kernel->machine->WriteRegister(PrevPCReg, kernel->machine->ReadRegister(PCReg));
				
				/* set programm counter to next instruction (all Instructions are 4 byte wide)*/
				kernel->machine->WriteRegister(PCReg, kernel->machine->ReadRegister(PCReg) + 4);
				
				/* set next programm counter for brach execution */
				kernel->machine->WriteRegister(NextPCReg, kernel->machine->ReadRegister(PCReg)+4);
			}
			
			return;
			
			ASSERTNOTREACHED();
			
			break;
			
			case SC_ConsoleRead:
			{
				cout<<"In Console Read System Call"<<endl;
				int reg4 = (int)kernel->machine->ReadRegister(4);
				int reg5 = (int)kernel->machine->ReadRegister(5);
				char* c = "Reading from Console";

				for (int i = 0; i < reg5; i++)
				{
					if(kernel->machine->WriteMem(reg4,1,(int)(*c)))
						reg4 = reg4 + 1;
					c++;
				}
				
				/* Modify return point */
				{
					/* set previous programm counter (debugging only)*/
					kernel->machine->WriteRegister(PrevPCReg, kernel->machine->ReadRegister(PCReg));
					
					/* set programm counter to next instruction (all Instructions are 4 byte wide)*/
					kernel->machine->WriteRegister(PCReg, kernel->machine->ReadRegister(PCReg) + 4);
					
					/* set next programm counter for brach execution */
					kernel->machine->WriteRegister(NextPCReg, kernel->machine->ReadRegister(PCReg)+4);
				}
				break;
			}
			
			case SC_ConsoleWrite:
			{
				cout<<"In Console Write System Call"<<endl;
				cout<<"Console Write of "<<endl;
				int reg4 = (int)kernel->machine->ReadRegister(4);
				int reg5 = (int)kernel->machine->ReadRegister(5);

				for (int i = 0; i < reg5; i++)
				{
					int c;
					if(kernel->machine->ReadMem(reg4, 1, &c))
						printf("%c",c);

					reg4 = reg4 + 1;
				}
				cout<<endl;

				/* Modify return point */
				{
					/* set previous programm counter (debugging only)*/
					kernel->machine->WriteRegister(PrevPCReg, kernel->machine->ReadRegister(PCReg));
					
					/* set programm counter to next instruction (all Instructions are 4 byte wide)*/
					kernel->machine->WriteRegister(PCReg, kernel->machine->ReadRegister(PCReg) + 4);
					
					/* set next programm counter for brach execution */
					kernel->machine->WriteRegister(NextPCReg, kernel->machine->ReadRegister(PCReg)+4);
				}
				break;
			}

			case SC_Exit:
			{
				cout<<" In Exit System Call"<<endl;
				cout<<" Exiting the current thread : "<<kernel->machine->ReadRegister(4)<<endl;
				kernel->currentThread->Finish();
				break;
			}

			case SC_ThreadFork:
			{
				cout<<"In Fork System Call"<<endl;
				int reg4 = kernel->machine->ReadRegister(4);
				Thread* t = new Thread("Fork");

				// AddrSpace *space = new AddrSpace;
				// space = kernel->currentThread->space;

				t->space = kernel->currentThread->space;


				t->Fork((VoidFunctionPtr)ForkFn, &reg4);

				/* Modify return point */
				{
					/* set previous programm counter (debugging only)*/
					kernel->machine->WriteRegister(PrevPCReg, kernel->machine->ReadRegister(PCReg));
					
					/* set programm counter to next instruction (all Instructions are 4 byte wide)*/
					kernel->machine->WriteRegister(PCReg, kernel->machine->ReadRegister(PCReg) + 4);
					
					/* set next programm counter for brach execution */
					kernel->machine->WriteRegister(NextPCReg, kernel->machine->ReadRegister(PCReg)+4);
				}
				break;
			}

			case SC_Exec:
			{
				cout<<"In Exec System Call"<<endl;
				int reg4 = kernel->machine->ReadRegister(4);

				Thread* t = new Thread("Fork ");
				t->Fork((VoidFunctionPtr)ExecFn, &reg4);

				{
					kernel->machine->WriteRegister(PrevPCReg, kernel->machine->ReadRegister(PCReg));
					kernel->machine->WriteRegister(PCReg, kernel->machine->ReadRegister(PCReg) + 4);
					kernel->machine->WriteRegister(NextPCReg, kernel->machine->ReadRegister(PCReg)+4);
				}
				break;
			}
			
			default:
			cerr << "Unexpected system call " << type << "\n";
			break;
		}
		
		case PageFaultException:
      	{
			// Handling Page Fault Exception

      		int freePos = kernel->machine->track->FindAndSet();

			// When free position available in Frame Table
      		if(freePos != -1)
      		{
      			TranslationEntry* entry = kernel->machine->frameTable.at(freePos);
      			int addr = kernel->machine->ReadRegister(BadVAddrReg);

        		char* buffer = new char[PageSize];
				unsigned int vpn = (unsigned) addr / PageSize;
        		int tID = kernel->currentThread->id;
        		int vpnPos = kernel->loc[tID];

        		kernel->swapFile->ReadAt(&buffer[0], PageSize, vpnPos+vpn*PageSize);
				int i = 0;
        		for(int j = freePos*PageSize; j < ((freePos*PageSize)+PageSize); j++)
        		{
        			kernel->machine->mainMemory[j] = buffer[i];
        			i++;
        		}
				entry->virtualPage = vpn;
				entry->physicalPage = freePos;
				entry->valid = true;
				entry->use = false;
				entry->dirty = false;
				entry->readOnly = false;
				entry->Thread_id = kernel->currentThread->id;
			}
      		else // When free position not available in Frame Table
      		{
      			freePos = rand()%125 + 1;
      			kernel->machine->track->Clear(freePos);

				TranslationEntry* entry = kernel->machine->frameTable.at(freePos);
				int tIDOld = entry->Thread_id;
				int vpnOld = kernel->loc[tIDOld];
				int sizeFree = freePos*PageSize;
				char* data = new char[PageSize];
				int vpn1 = entry->virtualPage;
				
				for(int i = 0; i < PageSize; i++)
        		{
            		data[i]=kernel->machine->mainMemory[sizeFree];
            		sizeFree++;
        		}
				kernel->swapFile->WriteAt(data, PageSize, vpnOld+vpn1*PageSize);
				delete data;
				int addr = kernel->machine->ReadRegister(BadVAddrReg);

				char* buffer= new char[PageSize];
				unsigned int vpn = (unsigned) addr / PageSize;
				int tID = kernel->currentThread->id;
				int vpnPos = kernel->loc[tID];

				kernel->swapFile->ReadAt(&buffer[0], PageSize,vpnPos+vpn*PageSize);

				int i = 0;
				for(int j = freePos*PageSize; j < ((freePos*PageSize)+PageSize); j++)
				{
					kernel->machine->mainMemory[j] = buffer[i];
					i++;
				}
				entry->virtualPage = vpn;
				entry->physicalPage = freePos;
				entry->valid = true;
				entry->use = false;
				entry->dirty = false;
				entry->readOnly = false;
				entry->Thread_id = kernel->currentThread->id;
				kernel->machine->track->Mark(freePos);
    		}
       		break;
    	}
		default:
		cerr << "Unexpected user mode exception" << (int)which << "\n";
		break;
	}
	return;
    ASSERTNOTREACHED();
}
