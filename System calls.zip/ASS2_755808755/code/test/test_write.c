#include "syscall.h"

int
main()
{
    char* buffer;

    Write_Console(buffer, 5);

    //Halt();

}