#include "syscall.h"

int
main()
{
    char* buffer;

    ThreadFork(0);

    //Halt();

}