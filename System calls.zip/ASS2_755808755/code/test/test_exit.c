#include "syscall.h"

int
main()
{
    char* buffer;

    ThreadExit(0);

    //Halt();

}