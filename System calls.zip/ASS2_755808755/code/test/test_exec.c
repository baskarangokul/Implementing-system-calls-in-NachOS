#include "syscall.h"

int
main()
{
    char* buffer;

    //ThreadExec("add.c");

    //Halt();

}