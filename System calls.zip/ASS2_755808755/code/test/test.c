#include "syscall.h"

int
main()
{
    char* buffer;
    Read_Console(buffer, 5);

    //Halt();

}